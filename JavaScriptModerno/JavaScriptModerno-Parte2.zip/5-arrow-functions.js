// Com a seta podemos simplificar a sintaxe da função

const square1 = (a) => {
  return a * a;
};

const square2 = (a) => a * a;

const square3 = a => a * a;

[1, 2, 3, 4].map(a => a * a);
